class CmpDealerAgentLoginModel {
  String mobileno = '';

  String password = '';

  String get getMobileno {
    return mobileno;
  }

  set setMobileNo(String contactNo) {
    mobileno = contactNo;
  }

  String get getPaasword {
    return password;
  }

  set setPassword(String password1) {
    password = password1;
  }
}
