class LoginModel {
  String username = '';

  String password = '';

  String get getUsername {
    return username;
  }

  set setUsername(String name) {
    username = name;
  }

  String get getPaasword {
    return password;
  }

  set setPassword(String password1) {
    password = password1;
  }
}
